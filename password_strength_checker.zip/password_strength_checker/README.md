# Password Strength Checker

A small desktop app (Windows & Linux) that assesses password strength in
real time as you type, with a color-coded meter, an estimated crack time,
and concrete suggestions for improvement.

![status](https://img.shields.io/badge/status-internship%20project-blue)

## Features

- Live strength meter (red -> green) as you type
- Estimated time-to-crack (e.g. "3 hours", "centuries")
- Concrete, actionable suggestions (not just "add a symbol")
- Show/hide password toggle
- Dark theme UI
- Company logo placeholder, top-right
- Cross-platform: tested on Windows and Linux

## How it works

Strength is assessed using [**zxcvbn**](https://github.com/dropbox/zxcvbn),
an open-source (MIT licensed) password strength estimator originally built
by Dropbox. Instead of naive rules like "must contain 1 digit and 1 symbol,"
zxcvbn checks the password against:

- the 30,000 most common passwords
- common English words and names
- keyboard patterns (`qwerty`, `asdf1234`)
- dates and years
- l33t-speak substitutions (`P@ssw0rd`)
- repeated/sequential characters (`aaa`, `1234`)

...and estimates realistic crack times based on that analysis. This is
much closer to how real attackers approach password guessing than simple
character-class rules.

We use the actively maintained Python port:
https://github.com/dwolfhub/zxcvbn-python (also MIT licensed).

## Project structure

```
password_strength_checker/
├── main.py              # entry point
├── requirements.txt
├── src/
│   ├── gui.py            # tkinter window, layout, live updates
│   ├── strength.py       # wraps zxcvbn, no GUI dependency
│   └── theme.py          # dark palette + ttk styling
├── assets/
│   └── logo.png          # replace with your company logo
└── README.md
```

The strength-checking logic (`strength.py`) is intentionally kept separate
from the GUI, so it can be reused or unit-tested without tkinter.

## Setup

Requires Python 3.10+ (tkinter ships with Python on Windows and macOS; on
Linux you may need to install it separately, see below).

```bash
# 1. clone / download the project, then from the project folder:
pip install -r requirements.txt

# 2. run it
python main.py
```

**Linux only** -- if you get `ModuleNotFoundError: No module named 'tkinter'`,
install it via your package manager first:

```bash
sudo apt install python3-tk        # Debian/Ubuntu
sudo dnf install python3-tkinter   # Fedora
```

## Customizing

- **Logo**: replace `assets/logo.png` with your company's logo (transparent
  PNG recommended). It's automatically resized to fit.
- **Company name**: update `COMPANY_NAME` in `src/gui.py` -- it's also used
  to penalize passwords that contain the company name (e.g. flag
  `AcmeCorp2024` as weak even though it "looks" complex).
- **Colors**: all colors live in `src/theme.py`.

## Acknowledgements

- [zxcvbn](https://github.com/dropbox/zxcvbn) by Dropbox -- MIT License
- [zxcvbn-python](https://github.com/dwolfhub/zxcvbn-python) -- MIT License
