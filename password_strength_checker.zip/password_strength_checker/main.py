"""
Entry point for the Password Strength Checker.

Run with:
    python main.py
"""

import tkinter as tk

from src.gui import PasswordStrengthApp


def main():
    root = tk.Tk()
    app = PasswordStrengthApp(root)  # noqa: F841 (kept alive by closure/bindings)
    root.mainloop()


if __name__ == "__main__":
    main()
