"""
Password Strength Checker - clean minimal GUI.

Standard tkinter window: uses the OS's native title bar, so close/minimize/
maximize buttons work automatically on both Windows and Linux -- no custom
code needed for that.

The signature element is a single continuous bar that eases smoothly toward
its target strength percent every time the password changes -- in both
directions -- rather than snapping instantly. This is done with a small
animation loop driven by root.after(), easing the displayed value toward
the target percent each frame and redrawing until it settles.
"""

import os
import tkinter as tk
from tkinter import ttk

from PIL import Image, ImageDraw, ImageTk

from .strength import assess_password
from .theme import (
    BG,
    BORDER,
    ENTRY_BG,
    ENTRY_FG,
    FAINT_FG,
    FONT_FAMILY,
    FG,
    MUTED_FG,
    PANEL_BG,
    SPACE_1,
    SPACE_2,
    SPACE_3,
    TRACK,
    apply_theme,
    interpolate_color,
    strength_label,
)

ASSETS_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets")
LOGO_PATH = os.path.join(ASSETS_DIR, "logo.png")
LOGO_SIZE = (48, 48)

COMPANY_NAME = "Your Company"  # TODO: replace with the real company name

BAR_HEIGHT = 10
ANIMATION_EASE = 0.18       # fraction of remaining distance covered per frame
ANIMATION_SETTLE = 0.3      # stop animating once within this % of the target
FRAME_MS = 16                # ~60fps


class PasswordStrengthApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Password Strength Checker")
        self.root.geometry("440x360")
        self.root.minsize(400, 340)

        apply_theme(self.root)

        self.target_percent = 0.0
        self.displayed_percent = 0.0
        self._anim_job = None

        self._build_header()
        self._build_body()

    # ------------------------------------------------------------------ #
    # Header
    # ------------------------------------------------------------------ #
    def _build_header(self):
        header = ttk.Frame(self.root, padding=(SPACE_3, SPACE_3, SPACE_3, SPACE_1))
        header.pack(fill="x")

        title_box = ttk.Frame(header)
        title_box.pack(side="left")

        ttk.Label(title_box, text="Password Strength", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            title_box, text="Type a password to see how strong it is.", style="Muted.TLabel"
        ).pack(anchor="w", pady=(2, 0))

        self.logo_image = self._load_logo()
        if self.logo_image is not None:
            tk.Label(header, image=self.logo_image, bg=BG, borderwidth=0).pack(side="right")

    def _load_logo(self):
        """Load and softly round the logo corners. Returns None if not found."""
        try:
            img = Image.open(LOGO_PATH).convert("RGBA")

            # center-crop to a square first, so it's never squished
            w, h = img.size
            side = min(w, h)
            left, top = (w - side) // 2, (h - side) // 2
            img = img.crop((left, top, left + side, top + side))

            img = img.resize(LOGO_SIZE, Image.LANCZOS)
            return ImageTk.PhotoImage(img)
        except (FileNotFoundError, OSError):
            return None

    # ------------------------------------------------------------------ #
    # Body
    # ------------------------------------------------------------------ #
    def _build_body(self):
        body = ttk.Frame(self.root, padding=(SPACE_3, SPACE_1, SPACE_3, SPACE_3))
        body.pack(fill="both", expand=True)

        # --- Password entry ---
        ttk.Label(body, text="Password", style="Muted.TLabel").pack(anchor="w", pady=(SPACE_2, SPACE_1))

        entry_row = ttk.Frame(body)
        entry_row.pack(fill="x")

        self.password_var = tk.StringVar()
        self.show_password = tk.BooleanVar(value=False)

        self.entry = tk.Entry(
        entry_row, textvariable=self.password_var, show="*", font=(FONT_FAMILY, 12),
        bg=ENTRY_BG, fg=ENTRY_FG, insertbackground=ENTRY_FG,
        relief="flat", highlightthickness=0, bd=0,
        )
        self.entry.pack(side="left", fill="x", expand=True, ipady=8)
        self.entry.bind("<KeyRelease>", self._on_password_change)
        self.entry.focus_set()

        ttk.Checkbutton(
            entry_row, text="Show", variable=self.show_password, command=self._toggle_visibility
        ).pack(side="left", padx=(SPACE_1, 0))

        # --- Animated bar ---
        self.bar_canvas = tk.Canvas(body, height=BAR_HEIGHT, bg=BG, highlightthickness=0)
        self.bar_canvas.pack(fill="x", pady=(SPACE_3, SPACE_1))
        self.bar_canvas.bind("<Configure>", lambda e: self._draw_bar())

        # --- Status row: strength word (left) + percent / crack time (right) ---
        status_row = ttk.Frame(body)
        status_row.pack(fill="x", pady=(SPACE_1, 0))

        self.strength_word = tk.Label(
            status_row, text="", bg=BG, fg=MUTED_FG, font=(FONT_FAMILY, 11, "bold")
        )
        self.strength_word.pack(side="left")

        self.detail_label = ttk.Label(status_row, text="", style="Faint.TLabel")
        self.detail_label.pack(side="right")

        # --- Suggestions ---
        suggestions_row = ttk.Frame(body)
        suggestions_row.pack(fill="x", pady=(SPACE_3, 0))   # no expand -> row hugs its content height
        self.accent_bar = tk.Frame(suggestions_row, bg=TRACK, width=2)
        self.accent_bar.pack(side="left", fill="y", pady=2)  # matches text block height, not window height
        self.feedback_label = tk.Label(
            suggestions_row,
            text="Start typing to get feedback.",
            bg=BG,
            fg=MUTED_FG,
            font=(FONT_FAMILY, 9),
            justify="left",
            wraplength=360,
            anchor="nw",
            padx=SPACE_1,
        )
        self.feedback_label.pack(side="left", fill="both", expand=True)

        self._draw_bar()

    # ------------------------------------------------------------------ #
    # Behavior
    # ------------------------------------------------------------------ #
    def _toggle_visibility(self):
        self.entry.config(show="" if self.show_password.get() else "*")

    def _on_password_change(self, event=None):
        password = self.password_var.get()
        result = assess_password(password, user_inputs=[COMPANY_NAME])

        self.target_percent = result["percent"] or 0.0

        if not password:
            self.strength_word.config(text="", fg=MUTED_FG)
            self.detail_label.config(text="")
            self.feedback_label.config(text="Start typing to get feedback.")
            self.accent_bar.config(bg=TRACK)
        else:
            self.detail_label.config(text=f"Cracked in {result['crack_time']}")
            if result["suggestions"]:
                self.feedback_label.config(text=" ".join(result["suggestions"]))
            else:
                self.feedback_label.config(text="No specific suggestions -- nice password.")

        self._start_animation()

    def _start_animation(self):
        if self._anim_job is None:
            self._animate_step()

    def _animate_step(self):
        diff = self.target_percent - self.displayed_percent

        if abs(diff) <= ANIMATION_SETTLE:
            self.displayed_percent = self.target_percent
            self._anim_job = None
        else:
            self.displayed_percent += diff * ANIMATION_EASE
            self._anim_job = self.root.after(FRAME_MS, self._animate_step)

        self._draw_bar()
        self._update_labels_for_display()

    def _update_labels_for_display(self):
        """Strength word and its color track the animating bar, not the raw target,
        so the label transitions in step with the visual motion."""
        percent = self.displayed_percent
        if self.password_var.get():
            color = interpolate_color(percent)
            self.strength_word.config(text=strength_label(percent), fg=color)
            self.accent_bar.config(bg=color)

    # ------------------------------------------------------------------ #
    # Bar rendering
    # ------------------------------------------------------------------ #
    def _draw_bar(self):
        canvas = self.bar_canvas
        canvas.delete("all")

        w = canvas.winfo_width() or 360
        h = BAR_HEIGHT
        radius = h / 2

        # track (full width, unfilled)
        self._rounded_rect(canvas, 0, 0, w, h, radius, fill=TRACK, outline="")

        # filled portion
        fill_w = max(h, w * (self.displayed_percent / 100.0)) if self.displayed_percent > 0 else 0
        if fill_w > 0:
            color = interpolate_color(self.displayed_percent)
            self._rounded_rect(canvas, 0, 0, fill_w, h, radius, fill=color, outline="")

    @staticmethod
    def _rounded_rect(canvas, x0, y0, x1, y1, r, **kwargs):
        r = min(r, (x1 - x0) / 2, (y1 - y0) / 2)
        points = [
            x0 + r, y0,
            x1 - r, y0,
            x1, y0,
            x1, y0 + r,
            x1, y1 - r,
            x1, y1,
            x1 - r, y1,
            x0 + r, y1,
            x0, y1,
            x0, y1 - r,
            x0, y0 + r,
            x0, y0,
        ]
        return canvas.create_polygon(points, smooth=True, **kwargs)