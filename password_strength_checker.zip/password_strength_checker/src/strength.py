"""
Password strength assessment.

Wraps the open-source `zxcvbn` library (MIT licensed, originally built by
Dropbox: https://github.com/dropbox/zxcvbn) and returns a small, clean
dictionary that the GUI can render directly. Keeping this separate from the
GUI means it can be unit-tested or reused (e.g. in a web backend) without
any tkinter dependency.
"""

from zxcvbn import zxcvbn


def assess_password(password: str, user_inputs: list[str] | None = None) -> dict:
    """
    Assess the strength of a password.

    Args:
        password: the password to evaluate.
        user_inputs: optional list of user-specific strings (name, email,
            company name, etc.) that zxcvbn will penalize if found in the
            password -- e.g. don't let "JohnDoe2024" score as strong for John Doe.

    Returns:
        A dict with:
            percent (float 0-100 or None): continuous strength value, derived
                from log10(guesses), used to smoothly animate the meter --
                far more granular than the raw 0-4 score, so small edits
                (like deleting a character) move the bar a little instead
                of snapping between 5 fixed positions.
            crack_time (str, human readable)
            suggestions (list[str])
    """
    if not password:
        return {"percent": None, "crack_time": "", "suggestions": []}

    result = zxcvbn(password, user_inputs=user_inputs or [])

    # zxcvbn's score thresholds roughly land at guesses_log10 = 3, 6, 8, 10.
    # Scaling log10(guesses) against 10 and clamping to 100 gives a smooth
    # continuous percent that lines up with those same boundaries.
    guesses_log10 = result.get("guesses_log10", 0)
    percent = max(0.0, min(100.0, (guesses_log10 / 10.0) * 100.0))

    crack_time = result["crack_times_display"]["offline_slow_hashing_1e4_per_second"]

    feedback = result.get("feedback", {})
    suggestions = []
    if feedback.get("warning"):
        suggestions.append(feedback["warning"])
    suggestions.extend(feedback.get("suggestions", []))

    return {
        "percent": percent,
        "crack_time": crack_time,
        "suggestions": suggestions,
    }