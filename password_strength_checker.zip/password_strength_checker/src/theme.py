"""
Clean neutral dark theme.

Deliberately restrained: no ornamentation, no secondary accent colors.
The only expressive color in the whole UI is the strength gradient on the
bar itself -- everything else (text, borders, panels) stays neutral gray
so the bar is the one thing that draws the eye.
"""

from tkinter import ttk

# --- Spacing scale (8px baseline grid) --------------------------------
SPACE_1 = 8
SPACE_2 = 16
SPACE_3 = 24
SPACE_4 = 32

# --- Core neutral palette ------------------------------------------------
BG = "#14151A"           # deep neutral charcoal
PANEL_BG = "#1B1D23"
BORDER = "#2A2C34"
TRACK = "#25272E"         # bar's unfilled track color

FG = "#F2F2F5"            # primary text
MUTED_FG = "#8B8D98"      # secondary text
FAINT_FG = "#5C5E68"      # tertiary / disabled text

ENTRY_BG = "#1D1F26"
ENTRY_FG = "#F2F2F5"

# --- Font ------------------------------------------------------------------
FONT_FAMILY = "Segoe UI"

# --- Strength gradient stops (percent -> hex), interpolated smoothly ----
GRADIENT_STOPS = [
    (0, "#E5484D"),    # red
    (25, "#F2994A"),   # orange
    (50, "#F2C94C"),   # yellow
    (75, "#6FCF97"),   # light green
    (100, "#27AE60"),  # deep green
]

# --- Strength labels by percent band (5 even 20-point bands) -------------
STRENGTH_BANDS = [
    (20, "Very Weak"),
    (40, "Weak"),
    (60, "Fair"),
    (80, "Strong"),
    (101, "Very Strong"),
]


def interpolate_color(percent: float) -> str:
    """Linearly interpolate a hex color along GRADIENT_STOPS for a given percent (0-100)."""
    percent = max(0.0, min(100.0, percent))

    for i in range(len(GRADIENT_STOPS) - 1):
        p0, c0 = GRADIENT_STOPS[i]
        p1, c1 = GRADIENT_STOPS[i + 1]
        if p0 <= percent <= p1:
            t = 0 if p1 == p0 else (percent - p0) / (p1 - p0)
            return _lerp_hex(c0, c1, t)
    return GRADIENT_STOPS[-1][1]


def _lerp_hex(c0: str, c1: str, t: float) -> str:
    r0, g0, b0 = int(c0[1:3], 16), int(c0[3:5], 16), int(c0[5:7], 16)
    r1, g1, b1 = int(c1[1:3], 16), int(c1[3:5], 16), int(c1[5:7], 16)
    r = round(r0 + (r1 - r0) * t)
    g = round(g0 + (g1 - g0) * t)
    b = round(b0 + (b1 - b0) * t)
    return f"#{r:02x}{g:02x}{b:02x}"


def strength_label(percent: float) -> str:
    for threshold, label in STRENGTH_BANDS:
        if percent < threshold:
            return label
    return STRENGTH_BANDS[-1][1]


def apply_theme(root):
    """Apply the theme to the root window and configure ttk styles."""
    root.configure(bg=BG)

    style = ttk.Style(root)
    # 'clam' is the most consistent theme across Windows/Linux for custom
    # colors -- the native themes largely ignore color overrides.
    style.theme_use("clam")

    style.configure("TFrame", background=BG)

    style.configure("TLabel", background=BG, foreground=FG, font=(FONT_FAMILY, 10))
    style.configure("Title.TLabel", background=BG, foreground=FG, font=(FONT_FAMILY, 15, "bold"))
    style.configure("Muted.TLabel", background=BG, foreground=MUTED_FG, font=(FONT_FAMILY, 9))
    style.configure("Faint.TLabel", background=BG, foreground=FAINT_FG, font=(FONT_FAMILY, 9))

    style.configure(
        "TEntry",
        fieldbackground=ENTRY_BG,
        foreground=ENTRY_FG,
        insertcolor=ENTRY_FG,
        bordercolor=BORDER,
        lightcolor=BORDER,
        darkcolor=BORDER,
        padding=10,
    )

    style.configure("TCheckbutton", background=BG, foreground=MUTED_FG, font=(FONT_FAMILY, 9))
    style.map("TCheckbutton", background=[("active", BG)])

    return style